"""
osquery-monitor dashboard — Flask web app.

Run:  python -m dashboard.app   (or: flask --app dashboard.app run)
"""

import csv
import io
import os
import sys
from datetime import datetime, timezone

from flask import Flask, Response, jsonify, render_template, request

# Allow running both as `python -m dashboard.app` and `python dashboard/app.py`
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dashboard import alerts as alert_engine  # noqa: E402
from dashboard import database  # noqa: E402

app = Flask(__name__, template_folder=os.path.join(os.path.dirname(__file__), "templates"))

# Optional shared secret — set API_KEY env var to enforce it. Empty = open (dev default).
EXPECTED_API_KEY = os.environ.get("OSQUERY_API_KEY", "")


def _is_online(last_seen: str) -> bool:
    """Endpoint is 'online' if seen within the last 5 minutes."""
    try:
        ts = datetime.fromisoformat(last_seen.replace("Z", "+00:00"))
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        return (datetime.now(timezone.utc) - ts).total_seconds() < 300
    except (ValueError, TypeError):
        return False


@app.route("/")
def index():
    endpoints = database.get_endpoints()
    alerts = database.get_alerts(resolved=False)
    for ep in endpoints:
        ep["online"] = _is_online(ep["last_seen"])
        ep["alert_count"] = sum(1 for a in alerts if a["endpoint_id"] == ep["id"])
    return render_template("index.html", endpoints=endpoints, alerts=alerts)


@app.route("/endpoint/<name>")
def endpoint_detail(name: str):
    endpoint = database.get_endpoint_by_name(name)
    if not endpoint:
        return render_template("endpoint.html", endpoint=None, name=name), 404
    eid = endpoint["id"]
    endpoint["online"] = _is_online(endpoint["last_seen"])
    detail = {
        "processes": database.get_latest_data(eid, "processes"),
        "network_connections": database.get_latest_data(eid, "network_connections"),
        "logged_in_users": database.get_latest_data(eid, "logged_in_users"),
        "installed_software": database.get_latest_data(eid, "installed_software"),
        "usb_devices": database.get_latest_data(eid, "usb_devices"),
        "failed_logins": database.get_latest_data(eid, "failed_logins"),
    }
    endpoint_alerts = [a for a in database.get_alerts(resolved=False) if a["endpoint_id"] == eid]
    return render_template("endpoint.html", endpoint=endpoint, name=name, detail=detail, alerts=endpoint_alerts)


@app.route("/api/data", methods=["POST"])
def receive_data():
    payload = request.get_json(silent=True) or {}
    if EXPECTED_API_KEY and payload.get("api_key") != EXPECTED_API_KEY:
        return jsonify({"error": "invalid api key"}), 401

    endpoint_name = payload.get("endpoint_name") or request.remote_addr or "unknown"
    data = payload.get("data") or {}
    ip = request.remote_addr

    endpoint_id = None
    for data_type, rows in data.items():
        endpoint_id = database.save_collection(endpoint_name, data_type, rows, ip=ip)

    raised = []
    if endpoint_id is not None:
        for alert in alert_engine.check_alerts(data):
            database.save_alert(endpoint_id, alert.severity, alert.title, alert.description)
            raised.append({"severity": alert.severity, "title": alert.title})

    return jsonify({"status": "ok", "endpoint": endpoint_name, "alerts_raised": raised}), 200


@app.route("/api/alerts")
def api_alerts():
    return jsonify(database.get_alerts(resolved=False))


@app.route("/api/alerts/<int:alert_id>/resolve", methods=["POST"])
def resolve(alert_id: int):
    if database.resolve_alert(alert_id):
        return jsonify({"status": "resolved"})
    return jsonify({"error": "alert not found"}), 404


@app.route("/export/csv")
def export_csv():
    rows = database.get_all_collections()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["id", "endpoint_name", "timestamp", "data_type", "data_json"])
    for r in rows:
        writer.writerow([r["id"], r["endpoint_name"], r["timestamp"], r["data_type"], r["data_json"]])
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment; filename=osquery_monitor_export.csv"},
    )


if __name__ == "__main__":
    database.init_db()
    app.run(host="0.0.0.0", port=5000, debug=False)
