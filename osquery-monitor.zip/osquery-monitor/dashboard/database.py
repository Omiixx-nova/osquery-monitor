"""
SQLite storage for osquery-monitor dashboard.

Tables:
  endpoints   — one row per known endpoint
  collections — raw query results (JSON) per endpoint / data_type
  alerts      — security alerts raised by the alert engine
"""

import json
import os
import sqlite3
from datetime import datetime, timezone

DB_PATH = os.environ.get("OSQUERY_DB", os.path.join(os.path.dirname(__file__), "..", "osquery_monitor.db"))


def _connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def init_db():
    """Create tables if they do not exist."""
    conn = _connect()
    try:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS endpoints (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                last_seen TEXT NOT NULL,
                ip_address TEXT,
                status TEXT DEFAULT 'online'
            );
            CREATE TABLE IF NOT EXISTS collections (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                endpoint_id INTEGER NOT NULL REFERENCES endpoints(id),
                timestamp TEXT NOT NULL,
                data_type TEXT NOT NULL,
                data_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                endpoint_id INTEGER NOT NULL REFERENCES endpoints(id),
                timestamp TEXT NOT NULL,
                severity TEXT NOT NULL,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                resolved INTEGER DEFAULT 0
            );
            """
        )
        conn.commit()
    finally:
        conn.close()


def _get_or_create_endpoint(conn, endpoint_name: str, ip: str | None) -> int:
    now = _utcnow()
    conn.execute(
        """
        INSERT INTO endpoints (name, last_seen, ip_address, status)
        VALUES (?, ?, ?, 'online')
        ON CONFLICT(name) DO UPDATE SET last_seen=excluded.last_seen,
            ip_address=COALESCE(excluded.ip_address, endpoints.ip_address),
            status='online'
        """,
        (endpoint_name, now, ip),
    )
    row = conn.execute("SELECT id FROM endpoints WHERE name = ?", (endpoint_name,)).fetchone()
    return int(row["id"])


def save_collection(endpoint_name: str, data_type: str, data, ip: str | None = None) -> int:
    """Save one data_type collection for an endpoint. Returns endpoint_id."""
    conn = _connect()
    try:
        endpoint_id = _get_or_create_endpoint(conn, endpoint_name, ip)
        conn.execute(
            "INSERT INTO collections (endpoint_id, timestamp, data_type, data_json) VALUES (?, ?, ?, ?)",
            (endpoint_id, _utcnow(), data_type, json.dumps(data)),
        )
        conn.commit()
        return endpoint_id
    finally:
        conn.close()


def get_endpoints():
    """Return all endpoints with last_seen, ordered by most recent."""
    conn = _connect()
    try:
        rows = conn.execute(
            "SELECT * FROM endpoints ORDER BY last_seen DESC"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_endpoint_by_name(name: str):
    conn = _connect()
    try:
        row = conn.execute("SELECT * FROM endpoints WHERE name = ?", (name,)).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()


def get_latest_data(endpoint_id: int, data_type: str):
    """Get the most recent collection for an endpoint + data_type (parsed JSON)."""
    conn = _connect()
    try:
        row = conn.execute(
            """
            SELECT data_json, timestamp FROM collections
            WHERE endpoint_id = ? AND data_type = ?
            ORDER BY id DESC LIMIT 1
            """,
            (endpoint_id, data_type),
        ).fetchone()
        if not row:
            return []
        try:
            return json.loads(row["data_json"])
        except (TypeError, json.JSONDecodeError):
            return []
    finally:
        conn.close()


def save_alert(endpoint_id: int, severity: str, title: str, description: str) -> int:
    conn = _connect()
    try:
        cur = conn.execute(
            "INSERT INTO alerts (endpoint_id, timestamp, severity, title, description, resolved) VALUES (?, ?, ?, ?, ?, 0)",
            (endpoint_id, _utcnow(), severity, title, description),
        )
        conn.commit()
        return int(cur.lastrowid)
    finally:
        conn.close()


def get_alerts(resolved: bool = False):
    """Get alerts (unresolved by default), newest first, with endpoint name."""
    conn = _connect()
    try:
        rows = conn.execute(
            """
            SELECT a.*, e.name AS endpoint_name
            FROM alerts a JOIN endpoints e ON e.id = a.endpoint_id
            WHERE a.resolved = ?
            ORDER BY a.id DESC
            """,
            (1 if resolved else 0,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def resolve_alert(alert_id: int) -> bool:
    conn = _connect()
    try:
        cur = conn.execute("UPDATE alerts SET resolved = 1 WHERE id = ?", (alert_id,))
        conn.commit()
        return cur.rowcount > 0
    finally:
        conn.close()


def get_all_collections():
    """Return every collection row (used for CSV export)."""
    conn = _connect()
    try:
        rows = conn.execute(
            """
            SELECT c.id, e.name AS endpoint_name, c.timestamp, c.data_type, c.data_json
            FROM collections c JOIN endpoints e ON e.id = c.endpoint_id
            ORDER BY c.id DESC
            """
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()
