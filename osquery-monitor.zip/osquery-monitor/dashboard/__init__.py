"""osquery-monitor dashboard package."""
