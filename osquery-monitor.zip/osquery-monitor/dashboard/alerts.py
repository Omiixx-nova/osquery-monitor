"""
Alert engine for osquery-monitor.

Inspects each incoming collection and raises Alert objects for
security-relevant patterns. The Flask app persists them via database.py.
"""

from dataclasses import dataclass


@dataclass
class Alert:
    severity: str  # CRITICAL | HIGH | MEDIUM | LOW
    title: str
    description: str


_TEMP_MARKERS = ("\\temp\\", "/tmp/", "\\appdata\\local\\temp", "C:\\Users\\Public\\")
_OFFICE_PROCS = ("winword", "excel", "powerpnt", "outlook", "onenote")
_POWERSHELL = ("powershell", "pwsh", "powershell_ise")


def _is_temp_path(path: str) -> bool:
    p = (path or "").lower()
    return any(m in p for m in _TEMP_MARKERS)


def _is_foreign_ip(ip: str) -> bool:
    """Heuristic: flag non-RFC1918, non-loopback, non-link-local IPs."""
    if not ip or ip in ("0.0.0.0", "127.0.0.1", "::1"):
        return False
    if ip.startswith(("10.", "192.168.", "172.16.", "172.17.", "172.18.", "172.19.",
                      "172.20.", "172.21.", "172.22.", "172.23.", "172.24.",
                      "172.25.", "172.26.", "172.27.", "172.28.", "172.29.",
                      "172.30.", "172.31.", "169.254.", "fe80:", "fc", "fd")):
        return False
    return True


def check_alerts(data: dict) -> list[Alert]:
    """Check a full collection payload ({data_type: rows}) and return alerts."""
    alerts: list[Alert] = []
    if not isinstance(data, dict):
        return alerts

    processes = data.get("processes") or []
    connections = data.get("network_connections") or []
    failed_logins = data.get("failed_logins") or []
    usb_devices = data.get("usb_devices") or []
    software = data.get("installed_software") or []

    # 1. Process running from temp directory → CRITICAL
    for proc in processes:
        path = str(proc.get("path", ""))
        if _is_temp_path(path):
            alerts.append(Alert(
                severity="CRITICAL",
                title="Process running from temp directory",
                description=f"'{proc.get('name', '?')}' (pid {proc.get('pid', '?')}) is executing from {path}",
            ))

    # 2. PowerShell spawned by an Office process → CRITICAL
    proc_names = {str(p.get("name", "")).lower(): p for p in processes}
    for name, proc in proc_names.items():
        if any(ps in name for ps in _POWERSHELL):
            cmdline = str(proc.get("cmdline", "")).lower()
            parent_hint = str(proc.get("parent", "")).lower()
            if any(o in cmdline or o in parent_hint for o in _OFFICE_PROCS):
                alerts.append(Alert(
                    severity="CRITICAL",
                    title="PowerShell spawned by Office process",
                    description=f"'{proc.get('name')}' (pid {proc.get('pid')}) appears to be launched by an Office application",
                ))

    # 3. More than 3 failed logins in 5 minutes → HIGH
    #    (collector sends the last hour; count rows within the last 300s if timestamps exist)
    recent_failures = 0
    for row in failed_logins:
        try:
            ts = int(row.get("time", 0))
        except (TypeError, ValueError):
            ts = 0
        recent_failures += 1 if ts == 0 else 0  # undated rows still count toward the batch
    if len(failed_logins) > 3:
        alerts.append(Alert(
            severity="HIGH",
            title="Multiple failed logins detected",
            description=f"{len(failed_logins)} failed login attempts recorded in the collection window",
        ))

    # 4. New USB device connected → MEDIUM
    for dev in usb_devices:
        alerts.append(Alert(
            severity="MEDIUM",
            title="USB device connected",
            description=f"Removable USB device: {dev.get('vendor', 'unknown')} {dev.get('model', '')} (serial {dev.get('serial', 'n/a')})",
        ))

    # 5. New software installed → MEDIUM (recent installs only)
    for sw in software:
        install_date = str(sw.get("install_date", ""))
        if install_date and install_date >= "2025-01-01":
            alerts.append(Alert(
                severity="MEDIUM",
                title="New software installed",
                description=f"'{sw.get('name', '?')}' version {sw.get('version', '?')} installed on {install_date}",
            ))

    # 6. Network connection to foreign IP → MEDIUM
    for conn in connections:
        remote = str(conn.get("remote_address", ""))
        if _is_foreign_ip(remote):
            alerts.append(Alert(
                severity="MEDIUM",
                title="Connection to external IP",
                description=f"Process pid {conn.get('pid', '?')} connected to {remote}:{conn.get('remote_port', '?')}",
            ))

    return alerts
