"""
osquery-monitor collector.

Runs osquery SQL queries on a schedule and POSTs the results to the
dashboard. If osquery is not installed (or fails), it falls back to
realistic mock data so the dashboard can still be demoed / tested.
"""

import json
import logging
import platform
import socket
import subprocess
import sys
import time
from datetime import datetime, timezone

import requests

try:
    from collector.config import API_KEY, COLLECTION_INTERVAL, DASHBOARD_URL, ENDPOINT_NAME
    from collector.queries import QUERIES
except ImportError:  # allow running as a plain script: python collector/osquery_collector.py
    from config import API_KEY, COLLECTION_INTERVAL, DASHBOARD_URL, ENDPOINT_NAME  # type: ignore
    from queries import QUERIES  # type: ignore

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("osquery-collector")


def get_endpoint_name() -> str:
    """Return configured endpoint name or auto-detect hostname."""
    if ENDPOINT_NAME:
        return ENDPOINT_NAME
    return socket.gethostname() or platform.node() or "unknown-endpoint"


def run_osquery_query(sql: str):
    """Run a single osquery SQL query via osqueryi. Returns list of rows."""
    try:
        result = subprocess.run(
            ["osqueryi", "--json", sql],
            capture_output=True,
            text=True,
            timeout=15,
        )
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or "osqueryi failed")
        output = result.stdout.strip()
        if not output:
            return []
        return json.loads(output)
    except FileNotFoundError:
        raise RuntimeError("osqueryi not found — osquery is not installed")
    except subprocess.TimeoutExpired:
        raise RuntimeError("osqueryi timed out")


def mock_data(data_type: str):
    """Realistic fallback data used when osquery is unavailable."""
    now = int(datetime.now(timezone.utc).timestamp())
    if data_type == "processes":
        return [
            {"pid": 1234, "name": "explorer.exe", "path": "C:\\Windows\\explorer.exe",
             "cmdline": "C:\\Windows\\explorer.exe", "username": "lawyer1"},
            {"pid": 5678, "name": "WINWORD.EXE", "path": "C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE",
             "cmdline": "WINWORD.EXE /n document.docx", "username": "lawyer1"},
            {"pid": 9012, "name": "chrome.exe", "path": "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
             "cmdline": "chrome.exe --profile-directory=Default", "username": "lawyer1"},
        ]
    if data_type == "network_connections":
        return [
            {"pid": 9012, "local_address": "192.168.1.50", "local_port": 54321,
             "remote_address": "142.250.80.46", "remote_port": 443, "state": "ESTABLISHED"},
        ]
    if data_type == "logged_in_users":
        return [
            {"username": "lawyer1", "host": "console", "time": now - 3600, "type": "user"},
        ]
    if data_type == "installed_software":
        return [
            {"name": "Microsoft Office", "version": "16.0.17928", "install_date": "2024-01-15"},
            {"name": "Adobe Acrobat Reader", "version": "24.0", "install_date": "2024-03-02"},
        ]
    if data_type == "usb_devices":
        return []
    if data_type == "failed_logins":
        return []
    return []


def collect_all():
    """Run every query, falling back to mock data per-query on failure."""
    collected = {}
    for data_type, sql in QUERIES.items():
        try:
            collected[data_type] = run_osquery_query(sql)
        except Exception as exc:  # noqa: BLE001 — collector must never crash on one query
            log.warning("Query '%s' failed (%s) — using mock data", data_type, exc)
            collected[data_type] = mock_data(data_type)
    return collected


def send_to_dashboard(endpoint_name: str, data: dict) -> bool:
    """POST one collection payload to the dashboard. Returns True on success."""
    payload = {
        "endpoint_name": endpoint_name,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "api_key": API_KEY,
        "data": data,
    }
    try:
        resp = requests.post(f"{DASHBOARD_URL.rstrip('/')}/api/data", json=payload, timeout=10)
        resp.raise_for_status()
        log.info("Sent %d data types to %s (HTTP %s)", len(data), DASHBOARD_URL, resp.status_code)
        return True
    except requests.RequestException as exc:
        log.error("Failed to send data to dashboard: %s", exc)
        return False


def main():
    endpoint = get_endpoint_name()
    log.info("osquery-monitor collector starting — endpoint=%s interval=%ss", endpoint, COLLECTION_INTERVAL)
    log.info("Dashboard: %s", DASHBOARD_URL)
    while True:
        try:
            data = collect_all()
            send_to_dashboard(endpoint, data)
        except Exception as exc:  # noqa: BLE001 — keep the loop alive
            log.exception("Collection cycle failed: %s", exc)
        time.sleep(COLLECTION_INTERVAL)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        log.info("Collector stopped by user.")
        sys.exit(0)
