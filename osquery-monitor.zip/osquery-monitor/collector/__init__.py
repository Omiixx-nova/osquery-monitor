"""osquery-monitor collector package."""
