"""
osquery SQL queries for law firm endpoint monitoring.
Each query targets a specific security-relevant data source.
"""

QUERIES = {
    "processes": """
        SELECT pid, name, path, cmdline, username
        FROM processes
        WHERE username != 'SYSTEM'
        LIMIT 50
    """,
    
    "network_connections": """
        SELECT pid, local_address, local_port,
               remote_address, remote_port, state
        FROM process_open_sockets
        WHERE state = 'ESTABLISHED'
        AND remote_address NOT IN ('0.0.0.0', '127.0.0.1', '::1')
        LIMIT 30
    """,
    
    "logged_in_users": """
        SELECT username, host, time, type
        FROM logged_in_users
        WHERE type = 'user'
    """,
    
    "installed_software": """
        SELECT name, version, install_date
        FROM programs
        ORDER BY install_date DESC
        LIMIT 100
    """,
    
    "usb_devices": """
        SELECT vendor, model, serial, removable
        FROM usb_devices
        WHERE removable = 1
    """,
    
    "failed_logins": """
        SELECT username, time, type
        FROM last
        WHERE type = 7
        AND time > (strftime('%s','now') - 3600)
    """
}
