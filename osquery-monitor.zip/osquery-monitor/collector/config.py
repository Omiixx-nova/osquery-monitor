"""
Configuration for osquery-monitor collector.
Edit these settings before deploying to endpoints.
"""

# Dashboard server URL
DASHBOARD_URL = "http://localhost:5000"

# How often to collect data (seconds)
COLLECTION_INTERVAL = 60

# Endpoint identifier (auto-detected if empty)
ENDPOINT_NAME = ""

# API key for authentication
API_KEY = "change-this-to-a-secret-key"
