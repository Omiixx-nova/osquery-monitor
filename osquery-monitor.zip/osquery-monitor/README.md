# osquery-monitor

![Python 3.11+](https://img.shields.io/badge/Python-3.11%2B-blue)
![Flask](https://img.shields.io/badge/Flask-3.0%2B-green)
![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)
![CyberOps](https://img.shields.io/badge/CyberOps-Endpoint%20Monitor-black)

Real-time endpoint visibility dashboard for small law firm networks. A lightweight [osquery](https://osquery.io/)-based collector on each workstation ships processes, network connections, logins, software, USB devices, and failed logins to a central Flask dashboard with a live alert feed and CSV export.

## Features

- **Collector** — runs 6 osquery SQL queries every 60s (processes, sockets, users, software, USB, failed logins)
- **Graceful fallback** — if osquery isn't installed, realistic mock data keeps the dashboard demoable
- **Alert engine** — temp-dir execution, Office→PowerShell, failed-login bursts, USB inserts, new software, foreign IPs
- **Dashboard** — dark terminal theme, live clock, endpoint grid, scrollable alert feed, 30s auto-refresh
- **CSV export** — one-click download of all collected data
- **SQLite storage** — zero-config database, no external services

## Architecture

```
┌─────────────────────────┐        POST /api/data        ┌──────────────────────────┐
│  Endpoint (each PC)     │ ───────────────────────────► │  Dashboard (Flask)       │
│  collector/             │   JSON + endpoint + API key  │  dashboard/app.py        │
│  osquery_collector.py   │                              │   ├─ database.py (SQLite)  │
│   └─ queries.py (SQL)   │                              │   ├─ alerts.py (engine)    │
│   └─ osqueryi (local)   │                              │   └─ templates/ (UI)       │
└─────────────────────────┘                              └──────────────────────────┘
        ▲                                                          ▲
        │ osquery SQL                                            │ GET /  ·  /endpoint/<name>
        └─────────────────────────┘                              │ /api/alerts · /export/csv
```

## Installation

### Prerequisites

- Python 3.11+
- [osquery 5.10.2](https://osquery.io/downloads/official/5.10.2) installed on each endpoint (dashboard works without it, using mock data)

### Linux

```bash
bash setup/install_linux.sh
```

### Windows

```bat
setup\install_windows.bat
```

## Quick Start

```bash
# 1. Install deps
pip install -r requirements.txt

# 2. Start the dashboard
python -m dashboard.app
# → open http://localhost:5000

# 3. Edit collector/config.py (DASHBOARD_URL, API_KEY), then start a collector
python collector/osquery_collector.py
```

> Set the `OSQUERY_API_KEY` environment variable on the dashboard to enforce API-key auth on `/api/data`.

## Dashboard

Dark theme (`#000000` background, `#00FF41` safe / `#FF4444` alert). The home page shows an endpoint grid with online/offline status dots, last-seen times, and per-endpoint alert counts, plus a scrollable alert feed with severity badges and resolve buttons. Clicking an endpoint opens its detail page with processes, network connections, logged-in users, and recent alerts. Fully responsive for mobile.

## Legal Disclaimer

> ⚠️ **Warning:** Deploy only on systems you own or have explicit written permission to monitor. Endpoint monitoring collects process, network, and login data — ensure compliance with your firm's privacy policy, client confidentiality obligations, and applicable laws (including India's DPDP Act) before rollout.

## Links

- CyberOps: https://cyberops-ivory.vercel.app
- osquery downloads: https://osquery.io/downloads/official/5.10.2

## License

MIT License — Copyright (c) 2026 Omkar Sawant. See [LICENSE](LICENSE) for details.
