@echo off
echo CyberOps osquery-monitor - Windows Setup
echo ==========================================
echo Installing Python requirements...
pip install -r requirements.txt
echo.
echo Please install osquery manually from:
echo https://osquery.io/downloads/official/5.10.2
echo.
echo After installing osquery, edit collector\config.py
echo Then run: python collector\osquery_collector.py
pause
