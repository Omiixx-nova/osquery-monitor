#!/bin/bash
echo "CyberOps osquery-monitor — Linux Setup"
echo "======================================="
# Install osquery
wget https://pkg.osquery.io/deb/osquery_5.10.2-1.linux_amd64.deb
dpkg -i osquery_5.10.2-1.linux_amd64.deb
# Install Python deps
pip3 install -r requirements.txt
echo "Setup complete. Edit collector/config.py then run:"
echo "python3 collector/osquery_collector.py"
